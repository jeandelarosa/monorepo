import { supabase } from '../config/supabase.js';

const CAMPOS = 'id, tipo, nombre, especificaciones, precio, imagen_url, created_at';

// GET /api/componentes
export async function listComponentes(req, res) {
  try {
    const { data: componentes, error } = await supabase
      .from('componentes')
      .select(CAMPOS)
      .order('created_at', { ascending: false });

    if (error) {
      throw error;
    }

    return res.status(200).json({ componentes });
  } catch (err) {
    console.error('Error en listComponentes:', err.message);
    return res.status(500).json({ error: 'Error al obtener el catálogo de componentes' });
  }
}

// GET /api/componentes/:id
export async function getComponenteById(req, res) {
  try {
    const { id } = req.params;

    const { data: componente, error } = await supabase
      .from('componentes')
      .select(CAMPOS)
      .eq('id', id)
      .single();

    if (error || !componente) {
      return res.status(404).json({ error: 'Componente no encontrado' });
    }

    return res.status(200).json({ componente });
  } catch (err) {
    console.error('Error en getComponenteById:', err.message);
    return res.status(500).json({ error: 'Error al obtener el componente' });
  }
}
