import { Router } from 'express';
import { listComponentes, getComponenteById } from '../controllers/componentes.js';

const router = Router();

router.get('/', listComponentes);
router.get('/:id', getComponenteById);

export default router;
