<script>
  import { authStore } from '../stores/auth.js';
  import { navigate } from '../lib/router.js';

  $: if (!$authStore.loading && !$authStore.usuario) {
    navigate('/login');
  }
</script>

{#if $authStore.loading}
  <div class="flex items-center justify-center py-20">
    <div class="h-8 w-8 animate-spin rounded-full border-2 border-gray-600 border-t-white"></div>
  </div>
{:else if $authStore.usuario}
  <slot />
{/if}
