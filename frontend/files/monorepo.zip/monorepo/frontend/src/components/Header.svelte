<script>
  import { authStore } from '../stores/auth.js';
  import { navigate } from '../lib/router.js';

  export let title = 'Mi App';

  function goTo(path) {
    return (e) => {
      e.preventDefault();
      navigate(path);
    };
  }

  function handleLogout() {
    authStore.logout();
    navigate('/');
  }
</script>

<header class="w-full px-6 py-4 bg-gray-900 text-white flex items-center justify-between">
  <a href="/" on:click={goTo('/')} class="text-lg font-bold">{title}</a>

  <nav class="flex items-center gap-4">
    <a href="/" on:click={goTo('/')} class="hover:underline">Inicio</a>
    <a href="/catalog" on:click={goTo('/catalog')} class="hover:underline">Catálogo</a>

    {#if $authStore.usuario}
      <span class="text-gray-300 text-sm">
        {$authStore.usuario.nombre || $authStore.usuario.email}
      </span>
      <button
        on:click={handleLogout}
        class="rounded bg-gray-700 px-3 py-1 text-sm hover:bg-gray-600"
      >
        Salir
      </button>
    {:else}
      <a
        href="/login"
        on:click={goTo('/login')}
        class="rounded bg-blue-600 px-3 py-1 text-sm hover:bg-blue-500"
      >
        Iniciar sesión
      </a>
    {/if}
  </nav>
</header>
