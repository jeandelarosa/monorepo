<script>
  import { authStore } from '../stores/auth.js';
  import { navigate } from '../lib/router.js';

  let email = '';
  let password = '';
  let nombre = '';
  let error = '';
  let loading = false;

  async function handleSubmit(e) {
    e.preventDefault();
    error = '';
    loading = true;
    try {
      await authStore.register(email, password, nombre);
      navigate('/');
    } catch (err) {
      error = err.message;
    } finally {
      loading = false;
    }
  }

  function goToLogin(e) {
    e.preventDefault();
    navigate('/login');
  }
</script>

<section class="flex min-h-[80vh] items-center justify-center px-4">
  <form on:submit={handleSubmit} class="w-full max-w-sm rounded-lg bg-gray-800 p-6 shadow-lg">
    <h1 class="mb-6 text-2xl font-bold text-white">Crear cuenta</h1>

    {#if error}
      <p class="mb-4 rounded bg-red-900/50 px-3 py-2 text-sm text-red-300">{error}</p>
    {/if}

    <label class="mb-1 block text-sm text-gray-300" for="nombre">Nombre</label>
    <input
      id="nombre"
      type="text"
      bind:value={nombre}
      class="mb-4 w-full rounded border border-gray-600 bg-gray-900 px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
    />

    <label class="mb-1 block text-sm text-gray-300" for="email">Email</label>
    <input
      id="email"
      type="email"
      bind:value={email}
      required
      class="mb-4 w-full rounded border border-gray-600 bg-gray-900 px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
    />

    <label class="mb-1 block text-sm text-gray-300" for="password">Contraseña</label>
    <input
      id="password"
      type="password"
      bind:value={password}
      required
      class="mb-6 w-full rounded border border-gray-600 bg-gray-900 px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
    />

    <button
      type="submit"
      disabled={loading}
      class="w-full rounded bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-500 disabled:opacity-50"
    >
      {loading ? 'Cargando...' : 'Registrarme'}
    </button>

    <p class="mt-4 text-center text-sm text-gray-400">
      ¿Ya tienes cuenta?
      <a href="/login" on:click={goToLogin} class="text-blue-400 hover:underline">Inicia sesión</a>
    </p>
  </form>
</section>
