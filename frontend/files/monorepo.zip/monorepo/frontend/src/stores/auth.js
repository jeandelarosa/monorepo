import { writable } from 'svelte/store';
import { post } from '../lib/api.js';

function readStoredUsuario() {
  try {
    const raw = localStorage.getItem('usuario');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function createAuthStore() {
  const { subscribe, set } = writable({
    usuario: null,
    token: null,
    loading: true,
  });

  function persist(usuario, token) {
    localStorage.setItem('token', token);
    localStorage.setItem('usuario', JSON.stringify(usuario));
  }

  function clear() {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
  }

  function rehydrate() {
    const token = localStorage.getItem('token');
    const usuario = readStoredUsuario();
    set({ usuario, token, loading: false });
  }

  async function login(email, password) {
    const data = await post('/api/auth/login', { email, password });
    persist(data.usuario, data.token);
    set({ usuario: data.usuario, token: data.token, loading: false });
    return data;
  }

  async function register(email, password, nombre) {
    const data = await post('/api/auth/register', { email, password, nombre });
    persist(data.usuario, data.token);
    set({ usuario: data.usuario, token: data.token, loading: false });
    return data;
  }

  function logout() {
    clear();
    set({ usuario: null, token: null, loading: false });
  }

  rehydrate();

  return { subscribe, login, register, logout };
}

export const authStore = createAuthStore();
