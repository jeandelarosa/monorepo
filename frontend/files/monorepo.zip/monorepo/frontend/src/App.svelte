<script>
  import Header from './components/Header.svelte';
  import Footer from './components/Footer.svelte';
  import Home from './pages/Home.svelte';
  import Catalog from './pages/Catalog.svelte';
  import Login from './pages/Login.svelte';
  import Register from './pages/Register.svelte';
  import { currentPath } from './lib/router.js';
</script>

<div class="min-h-screen flex flex-col bg-gray-950 text-white">
  <Header />

  <main class="flex-1">
    {#if $currentPath === '/login'}
      <Login />
    {:else if $currentPath === '/register'}
      <Register />
    {:else if $currentPath === '/catalog'}
      <Catalog />
    {:else}
      <Home />
    {/if}
  </main>

  <Footer />
</div>
